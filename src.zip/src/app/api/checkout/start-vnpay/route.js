import { NextResponse } from "next/server";
import connectDB from "@/lib/mongodb";
import Booking from "@/models/booking";
import { buildVnpayUrl } from "@/lib/vnpay";

export async function POST(req) {
  try {
    const body = await req.json();
    const { showtimeId, seatIds, total, ticketType, customer } = body || {};

    if (!showtimeId || !seatIds || !seatIds.length || !total) {
      return NextResponse.json({ error: "Thiếu dữ liệu" }, { status: 400 });
    }

    await connectDB();
    const booking = await Booking.create({
      showtime: showtimeId,
      seats: seatIds,
      ticketType,
      total,
      status: "pending",
      paymentMethod: "vnpay",
      customer,
    });

    const tmnCode = process.env.VNP_TMN_CODE;
    const hashSecret = process.env.VNP_HASH_SECRET;
    const returnUrl = process.env.VNP_RETURN_URL;
    const paymentUrl = process.env.VNP_PAYMENT_URL;
    const ipAddr =
      (req.headers.get("x-forwarded-for") || "127.0.0.1").split(",")[0].trim();

    const payUrl = buildVnpayUrl({
      amount: total,
      orderId: booking._id.toString(),
      orderInfo: `Thanh toán vé #${booking._id}`,
      ipAddr,
      returnUrl,
      tmnCode,
      hashSecret,
      paymentUrl,
    });

    return NextResponse.json({ ok: true, bookingId: booking._id, payUrl });
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { error: "Không thể khởi tạo thanh toán VNPAY" },
      { status: 500 }
    );
  }
}
