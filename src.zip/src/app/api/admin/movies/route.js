// app/api/admin/movies/route.js
import connectDB from "@/lib/mongodb";
import Movie from "@/models/movies";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    await connectDB();
    const movies = await Movie.find().populate("genres").sort({ createdAt: -1 });
    return NextResponse.json(movies);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Database error" }, { status: 500 });
  }
}
