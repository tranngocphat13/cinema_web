import { NextResponse } from "next/server";
import { verifyReturn } from "@/lib/vnpay";
import connectDB from "@/lib/mongodb";
import Booking from "@/models/booking";

async function handler(req) {
  try {
    let params = {};
    if (req.method === "GET") {
      const url = new URL(req.url);
      params = Object.fromEntries(url.searchParams.entries());
    } else {
      const ct = req.headers.get("content-type") || "";
      if (ct.includes("application/json")) params = await req.json();
      else params = Object.fromEntries(new URLSearchParams(await req.text()));
    }

    const { isValid } = verifyReturn(params, process.env.VNP_HASH_SECRET);
    if (!isValid) return NextResponse.json({ RspCode: "97", Message: "Invalid signature" });

    const orderId = params.vnp_TxnRef;
    const respCode = params.vnp_ResponseCode;
    const transStatus = params.vnp_TransactionStatus;
    const vnpAmount = Number(params.vnp_Amount || 0) / 100;

    await connectDB();
    const booking = await Booking.findById(orderId);
    if (!booking)
      return NextResponse.json({ RspCode: "01", Message: "Order not found" });

    if (booking.total && Math.round(vnpAmount) !== booking.total) {
      return NextResponse.json({ RspCode: "04", Message: "Invalid amount" });
    }

    if (booking.status === "paid") {
      return NextResponse.json({ RspCode: "02", Message: "Order already confirmed" });
    }

    if (respCode === "00" && transStatus === "00") {
      booking.status = "paid";
      booking.paymentMethod = "vnpay";
    } else {
      booking.status = "canceled";
      booking.paymentMethod = "vnpay";
    }

    await booking.save();
    return NextResponse.json({ RspCode: "00", Message: "Confirm Success" });
  } catch (e) {
    console.error("IPN error:", e);
    return NextResponse.json({ RspCode: "99", Message: "Unknown error" });
  }
}

export const GET = handler;
export const POST = handler;
