import { NextResponse } from "next/server";
import { verifyReturn } from "@/lib/vnpay";

export async function GET(req) {
  const url = new URL(req.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const { isValid } = verifyReturn(params, process.env.VNP_HASH_SECRET);
  const success = isValid && params.vnp_ResponseCode === "00";

  return NextResponse.json({
    success,
    message: success ? "Thanh toán thành công" : "Thanh toán thất bại",
    vnp_ResponseCode: params.vnp_ResponseCode,
    vnp_TxnRef: params.vnp_TxnRef,
    vnp_Amount: params.vnp_Amount,
    raw: params,
  });
}
