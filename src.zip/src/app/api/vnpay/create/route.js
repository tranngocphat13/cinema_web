import { NextResponse } from "next/server";
import { buildVnpayUrl } from "@/lib/vnpay";

export async function POST(req) {
  try {
    const { amount, orderId, orderInfo, bankCode } = await req.json();

    if (!amount || !orderId) {
      return NextResponse.json({ error: "Thiếu amount hoặc orderId" }, { status: 400 });
    }

    // đảm bảo amount là số
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      return NextResponse.json({ error: "Amount không hợp lệ" }, { status: 400 });
    }

    const ipAddr = (req.headers.get("x-forwarded-for") || "127.0.0.1")
      .split(",")[0]
      .trim();

    const payUrl = buildVnpayUrl({
      amount: amt,
      orderId: String(orderId),
      orderInfo: orderInfo || `Thanh toan don hang ${orderId}`,
      ipAddr,
      returnUrl: process.env.VNP_RETURN_URL,
      tmnCode: process.env.VNP_TMN_CODE,
      hashSecret: process.env.VNP_HASH_SECRET,
      paymentUrl: process.env.VNP_PAYMENT_URL,
      bankCode,
    });

    return NextResponse.json({ payUrl });
  } catch (e) {
    console.error("VNPAY create error:", e);
    return NextResponse.json({ error: "Lỗi tạo thanh toán" }, { status: 500 });
  }
}
