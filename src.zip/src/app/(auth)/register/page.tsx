import RegisterForm from "@/components/forms/RegisterForm";
import React from "react";

export default function page() {
  return (
    <RegisterForm />
  );
}
