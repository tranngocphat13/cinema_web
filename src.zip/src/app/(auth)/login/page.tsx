import LoginForm from '@/components/forms/LoginForm'
import React from 'react'

export default function page() {
  return (
    <div><LoginForm /></div>
  )
}
