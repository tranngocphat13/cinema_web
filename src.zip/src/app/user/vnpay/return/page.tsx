'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';

export default function Page() {
  const searchParams = useSearchParams();
  const [message, setMessage] = useState('Đang kiểm tra kết quả...');

  useEffect(() => {
    const checkPayment = async () => {
      const query = searchParams.toString();
      const res = await fetch(`/api/vnpay/return?${query}`);
      const data = await res.json();
      setMessage(data.message);
    };
    if (searchParams.size > 0) checkPayment();
  }, [searchParams]);

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4">
      <h1 className="text-2xl font-bold mb-4">Kết quả thanh toán</h1>
      <p className="text-lg text-gray-700">{message}</p>
    </main>
  );
}
