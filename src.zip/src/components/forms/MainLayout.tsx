import NowPlayingPage from "@/app/user/movies/now-playing/page";


export default function HomePage() {
  return (
    <NowPlayingPage/>
  );
}
